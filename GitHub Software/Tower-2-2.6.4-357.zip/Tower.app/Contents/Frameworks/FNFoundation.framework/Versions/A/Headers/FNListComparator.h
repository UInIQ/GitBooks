//
//  FNListComparator.h
//  FNFoundation
//
//  Created by Heiko Witte on 22.03.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FNOrderedCollectionComparator.h"

@class FNListChangeset;
@interface FNListComparator : NSObject <FNOrderedCollectionComparator>
- (FNListChangeset *)compareList:(NSArray<id<FNListItem>> *)oldItems withList:(NSArray<id<FNListItem>> *)newItems;
@end
