//
//  FNRESTAPIAuthenticationCredentials.h
//  FNFoundation
//
//  Created by Heiko Witte on 19.10.16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, FNRESTAPIAuthenticationMethod) {
    FNRESTAPIAuthenticationDefault,
    FNRESTAPIAuthenticationBasic,
    FNRESTAPIAuthenticationOAuth,
    FNRESTAPIAuthenticationNTLM
};

@interface FNRESTAPIAuthenticationCredentials : NSObject
@property (nonatomic) FNRESTAPIAuthenticationMethod authenticationMethod;
@property (nonatomic, nullable) NSString *userName;
@property (nonatomic, nullable) NSString *password;
@property (nonatomic, nullable) NSString *token;
@end
