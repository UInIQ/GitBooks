//
//  FNListItem.h
//  FNFoundation
//
//  Created by Heiko Witte on 22.03.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#ifndef FNListItem_h
#define FNListItem_h

@protocol FNListItem <NSObject>
@property (nonatomic, readonly) NSString *identifier;
@end

#endif /* FNListItem_h */
