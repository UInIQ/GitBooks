//
//  FNListChangeType.h
//  FNFoundation
//
//  Created by Heiko Witte on 22.03.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#ifndef FNListChangeType_h
#define FNListChangeType_h

typedef NS_ENUM(NSUInteger, FNListChangeType) {
    FNListChangeInsert = 0,
    FNListChangeDelete,
    FNListChangeMove
};

#endif /* FNListChangeType_h */
