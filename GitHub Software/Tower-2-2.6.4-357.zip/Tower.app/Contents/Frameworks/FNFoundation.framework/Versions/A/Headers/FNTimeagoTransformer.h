//
//  FNTimeagoTransformer.h
//  FNFoundation
//
//  Created by jens bissinger on 6/18/13.
//  Copyright (c) 2013 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNTimeagoTransformer : NSValueTransformer

@end
