//
//  NSStringToNSURLTransformer.h
//  GitLabAPI
//
//  Created by Alexander Rinass on 26/05/15.
//  Copyright (c) 2015 fournova Software GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSStringToNSURLTransformer : NSValueTransformer

@end
