//
//  FNListManagerDelegate.h
//  FNFoundation
//
//  Created by Heiko Witte on 22.03.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#ifndef FNListManagerDelegate_h
#define FNListManagerDelegate_h

#import "FNListItem.h"

@protocol FNListManagerDelegate
- (void)listManagerDidInsertItemsAtIndexPaths:(NSIndexSet *)indexPaths list:(NSArray<id<FNListItem>> *)list;
- (void)listManagerDidDeleteItemsAtIndexPaths:(NSIndexSet *)indexPaths list:(NSArray<id<FNListItem>> *)list;
- (void)listManagerDidMoveItemAtIndex:(NSUInteger)index toIndex:(NSUInteger)newIndex list:(NSArray<id<FNListItem>> *)list;
@end

#endif /* FNListManagerDelegate_h */
