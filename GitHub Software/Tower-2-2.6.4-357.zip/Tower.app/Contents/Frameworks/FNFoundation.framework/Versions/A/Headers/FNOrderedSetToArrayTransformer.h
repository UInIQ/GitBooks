//
//  FNOrderedSetToArrayTransformer.h
//  FNFoundation
//
//  Created by Alexander Rinass on 05.07.13.
//  Copyright (c) 2013 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNOrderedSetToArrayTransformer : NSValueTransformer

@end
