//
//  FNOptionType.h
//  OptionParser
//
//  Created by Heiko Witte on 13.12.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#ifndef FNOptionType_h
#define FNOptionType_h

typedef NS_ENUM(NSUInteger, FNOptionType) {
    FNOptionTypeNone,
    FNOptionTypeString,
    FNOptionTypeNumeric,
    FNOptionTypeBoolean,
    FNOptionTypeStringList,
    FNOptionTypeNumericList
};

#endif /* FNOptionType_h */
