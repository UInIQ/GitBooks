//
//  NSDateToRelativeDateStringTransformer.h
//  FNFoundation
//
//  Created by Alexander Rinass on 17/02/2017.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateToRelativeDateStringTransformer : NSValueTransformer

@end
