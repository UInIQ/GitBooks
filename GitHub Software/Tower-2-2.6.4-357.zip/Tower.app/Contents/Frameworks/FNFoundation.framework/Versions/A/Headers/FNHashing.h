//
//  FNHashing.h
//  FNFoundation
//
//  Created by Heiko Witte on 17.03.17.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FNHashing <NSObject>
@property (nonatomic, readonly) NSString *hashStringValue;
@end
