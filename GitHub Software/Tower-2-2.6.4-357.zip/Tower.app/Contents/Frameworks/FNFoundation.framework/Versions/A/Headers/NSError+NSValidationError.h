//
//  NSError+NSValidationError.h
//  FNFoundation
//
//  Created by Alexander Rinass on 06/06/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSError (NSValidationError)

+ (instancetype)validationErrorWithKey:(NSString *)key value:(id)value userInfo:(NSDictionary *)userInfo;
+ (instancetype)multipleValidationErrorsErrorWithValidationErrors:(NSArray<NSError *> *)errors userInfo:(NSDictionary *)userInfo;

@end
