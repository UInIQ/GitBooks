//
//  FNIdentifierMap.h
//  TreeDiffUnique
//
//  Created by Heiko Witte on 14.04.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNIdentifierMap : NSObject

+ (instancetype)sharedIdentifierMap;

- (NSUInteger)identifierForString:(NSString *)identifierString;

@end
