//
//  NSString+Counting.h
//  FNFoundation
//
//  Created by Heiko Witte on 07.03.17.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FNCounting)
@property (nonatomic, readonly) NSUInteger lineCount;
@end
