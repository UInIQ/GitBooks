//
//  NSString+FNUniqueIdentifier.h
//  FNFoundation
//
//  Created by Alexander Rinaß on 20.02.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FNUniqueIdentifier)

+ (instancetype)UUID;

@end
