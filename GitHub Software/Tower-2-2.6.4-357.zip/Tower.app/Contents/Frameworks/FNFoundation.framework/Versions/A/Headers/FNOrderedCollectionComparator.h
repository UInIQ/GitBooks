//
//  FNListComparator.h
//  FNFoundation
//
//  Created by Heiko Witte on 22.03.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#ifndef FNOrderedCollectionComparator_h
#define FNOrderedCollectionComparator_h

#import "FNListItem.h"
#import "FNListChangeset.h"

@protocol FNOrderedCollectionComparator <NSObject>
- (FNListChangeset *)compareList:(NSArray<id<FNListItem>> *)oldItems withList:(NSArray<id<FNListItem>> *)newItems;
@end

#endif /* FNOrderedCollectionComparator_h */
