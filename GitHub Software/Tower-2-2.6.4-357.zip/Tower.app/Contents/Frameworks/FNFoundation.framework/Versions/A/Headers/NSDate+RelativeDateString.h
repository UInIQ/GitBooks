//
//  NSDate+RelativeDateString.h
//  FNFoundation
//
//  Created by Alexander Rinass on 17/02/2017.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (RelativeDateString)
@property (nonatomic, readonly, nonnull) NSString *distanceOfTimeInWords;
@end
