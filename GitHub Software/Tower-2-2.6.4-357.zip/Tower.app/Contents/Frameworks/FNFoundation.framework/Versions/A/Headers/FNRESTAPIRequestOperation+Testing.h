//
//  FNRESTAPIRequestOperation+Testing.h
//  FNFoundation
//
//  Created by Alexander Rinass on 28/05/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

#import <FNFoundation/FNFoundation.h>

@interface FNRESTAPIRequestOperation (Testing)

- (BOOL)execute:(NSError * __autoreleasing *)error;
- (void)_setResponseWithStatusCode:(NSInteger)statusCode data:(NSData *)data;

@end
