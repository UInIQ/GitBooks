//
//  NSString+FNQueryParams.h
//  FNFoundation
//
//  Created by Alexander Rinass on 22/09/15.
//  Copyright © 2015 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FNQueryParams)
@property (nonatomic, readonly) NSDictionary *queryParams;
@end
