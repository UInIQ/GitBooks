//
//  FNQueueManager.h
//  FNAppKit
//
//  Created by Alexander Rinass on 20/01/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNQueueManager : NSObject
@property (nonatomic, readonly) NSArray *allQueues;

+ (instancetype)sharedManager;

- (void)addQueue:(NSOperationQueue *)queue;
- (NSOperationQueue *)queueForName:(NSString *)name;

@end
