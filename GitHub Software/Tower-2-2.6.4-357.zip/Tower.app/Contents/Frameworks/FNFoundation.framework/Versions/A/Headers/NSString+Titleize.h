//
//  NSString+Titleize.h
//  FNFoundation
//
//  Created by Alexander Rinass on 11/01/2017.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Titleize)
@property (nonatomic, readonly) NSString *titleize;
@end
