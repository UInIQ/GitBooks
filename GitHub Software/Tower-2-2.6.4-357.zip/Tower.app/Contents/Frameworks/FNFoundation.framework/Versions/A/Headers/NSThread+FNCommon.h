//
//  NSThread+FNCommon.h
//  FNFoundation
//
//  Created by Alexander Rinaß on 31.05.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSThread (FNCommon)

- (NSUInteger)identifier;

@end
