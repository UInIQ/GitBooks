//
//  NSString+FNCamelize.h
//  FNFoundation
//
//  Created by Alexander Rinass on 13/03/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FNCamelize)

- (NSString *)camelizedString;

@end
