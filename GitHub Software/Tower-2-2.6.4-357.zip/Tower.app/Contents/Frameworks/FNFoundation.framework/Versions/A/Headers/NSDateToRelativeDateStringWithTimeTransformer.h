//
//  NSDateToRelativeDateStringWithTimeTransformer.h
//  FNFoundation
//
//  Created by Heiko Witte on 08.03.17.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateToRelativeDateStringWithTimeTransformer : NSValueTransformer

@end
