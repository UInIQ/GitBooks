//
//  NSString+HTTPMethods.h
//  FNFoundation
//
//  Created by Alexander Rinass on 19/05/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HTTPMethods)
@property (nonatomic, readonly, getter=isGETMethod) BOOL GETMethod;
@property (nonatomic, readonly, getter=isPOSTMethod) BOOL POSTMethod;
@property (nonatomic, readonly, getter=isDELETEMethod) BOOL DELETEMethod;
@property (nonatomic, readonly, getter=isPUTMethod) BOOL PUTMethod;
@property (nonatomic, readonly, getter=isPATCHMethod) BOOL PATCHMethod;
@end
