//
//  FNListChange.h
//  FNFoundation
//
//  Created by Heiko Witte on 22.03.16.
//  Copyright © 2016 fournova Software GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FNListChangeType.h"
#import "FNListItem.h"

@interface FNListChange : NSObject
@property (nonatomic) FNListChangeType type;
@property (nonatomic) id<FNListItem> item;
@property (nonatomic) NSInteger index;
@property (nonatomic) NSInteger oldIndex;
@end
