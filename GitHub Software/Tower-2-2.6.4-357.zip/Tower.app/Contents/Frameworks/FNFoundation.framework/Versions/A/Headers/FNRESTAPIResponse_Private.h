//
//  FNRESTAPIResponse_Private.h
//  FNFoundation
//
//  Created by Alexander Rinass on 27/05/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

#import <FNFoundation/FNFoundation.h>

@interface FNRESTAPIResponse ()
@property (nonatomic, readwrite) NSInteger statusCode;
@property (nonatomic, readwrite) NSDictionary *headers;
@property (nonatomic, readwrite) NSString *body;
@property (nonatomic, readwrite) id result;
@property (nonatomic, readwrite) NSError *error;
@property (nonatomic, readwrite) NSData *serverTrustExceptionCookie;
@end
