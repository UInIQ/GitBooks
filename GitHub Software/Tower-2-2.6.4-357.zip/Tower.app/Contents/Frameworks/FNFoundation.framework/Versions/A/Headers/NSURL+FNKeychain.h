//
//  NSURL+FNKeychain.h
//  FNFoundation
//
//  Created by Alexander Rinass on 05/07/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (FNKeychain)
@property (nonatomic, readonly) NSURL *normalizedKeychainURL;
@end
