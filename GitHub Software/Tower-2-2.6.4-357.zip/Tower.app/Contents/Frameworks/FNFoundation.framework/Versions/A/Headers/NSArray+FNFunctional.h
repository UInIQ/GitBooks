//
//  NSArray+FNFunctional.h
//  FNFoundation
//
//  Created by Heiko Witte on 20.04.16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray<__covariant T> (FNFunctional)

- (NSArray<T> * _Nonnull)filter:(BOOL (^ _Nonnull)(T _Nonnull item))filter;
- (NSArray * _Nonnull)map:(id _Nonnull (^ _Nonnull)(T _Nonnull item))map;
- (id _Nonnull)reduce:(id _Nonnull)initialValue combine:(id _Nonnull (^ _Nonnull)(id _Nonnull value, T _Nonnull item))combine;

@end
