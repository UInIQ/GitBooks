//
//  GitLabAPIModel.h
//  GitLabAPI
//
//  Created by Alexander Rinass on 26/05/15.
//  Copyright (c) 2015 fournova Software GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNRESTAPIModel : NSObject

+ (NSArray *)propertyMappings;
+ (NSDictionary *)propertyMappingsByJSONPropertyName;
+ (NSDictionary *)propertyMappingsByModelPropertyName;

+ (instancetype)objectWithJSONObject:(NSDictionary *)jsonObject;

@property (nonatomic, readonly) NSDictionary *writableJSONProperties;
@property (nonatomic, readonly) NSDictionary *JSONRepresentation;

- (BOOL)isEqualToObject:(id)object;

@end
