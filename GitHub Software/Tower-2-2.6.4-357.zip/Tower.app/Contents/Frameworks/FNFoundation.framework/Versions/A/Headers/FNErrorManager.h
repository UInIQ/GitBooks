//
//  FNError.h
//  FNFoundation
//
//  Created by Alexander Rinass on 29/04/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNErrorManager : NSObject

+ (instancetype)sharedManager;

- (NSDictionary *)allErrorDefinitionsByDomain;
- (void)addErrorDefinitions:(NSArray *)errorDefinitions forErrorDomain:(NSString *)errorDomain;
- (void)addErrorDefinition:(NSDictionary *)errorDefinition forErrorDomain:(NSString *)errorDomain;

- (NSError *)errorWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(NSDictionary *)userInfo;

@end
