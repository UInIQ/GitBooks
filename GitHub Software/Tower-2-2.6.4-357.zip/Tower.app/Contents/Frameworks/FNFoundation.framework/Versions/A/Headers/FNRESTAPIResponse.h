//
//  FNRESTAPIResponse.h
//  FNFoundation
//
//  Created by Alexander Rinass on 27/05/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNRESTAPIResponse : NSObject
@property (nonatomic, readonly) NSInteger statusCode;
@property (nonatomic, readonly) NSDictionary *headers;
@property (nonatomic, readonly) NSString *body;
@property (nonatomic, readonly) id result;
@property (nonatomic, readonly) NSError *error;
@property (nonatomic, readonly) BOOL hasError;
@property (nonatomic, readonly) NSData *serverTrustExceptionCookie;
@end
