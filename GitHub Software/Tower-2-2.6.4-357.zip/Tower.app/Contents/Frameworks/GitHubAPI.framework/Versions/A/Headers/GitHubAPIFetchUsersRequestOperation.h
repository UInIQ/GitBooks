//
//  GitHubSearchUsersAPIRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 19.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@interface GitHubAPIFetchUsersRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) NSString *keyword;
@property (nonatomic, readonly) NSArray *users;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials keyword:(NSString *)keyword;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials keyword:(NSString *)keyword;

@end
