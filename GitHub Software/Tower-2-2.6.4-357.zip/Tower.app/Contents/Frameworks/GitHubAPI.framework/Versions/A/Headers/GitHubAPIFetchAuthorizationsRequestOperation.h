//
//  GitHubFetchAuthorizationsRequestOperation.h
//  GitHubAPI
//
//  Created by jens bissinger on 27/05/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@interface GitHubAPIFetchAuthorizationsRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) NSDictionary *options;
@property (nonatomic, readonly) NSArray *authorizations;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials options:(NSDictionary *)options;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials options:(NSDictionary *)options;

@end
