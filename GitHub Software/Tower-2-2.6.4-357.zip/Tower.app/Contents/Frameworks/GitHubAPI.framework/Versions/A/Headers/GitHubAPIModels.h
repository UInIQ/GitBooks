//
//  GitHubModels.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 23/04/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIAccount.h"
#import "GitHubAPIApp.h"
#import "GitHubAPIAuthorization.h"
#import "GitHubAPICredentials.h"
#import "GitHubAPIPlan.h"
#import "GitHubAPIPublicKey.h"
#import "GitHubAPIRepository.h"
#import "GitHubAPISearchResult.h"
