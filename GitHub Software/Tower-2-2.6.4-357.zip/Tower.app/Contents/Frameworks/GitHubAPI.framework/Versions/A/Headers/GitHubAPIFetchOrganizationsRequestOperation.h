//
//  GitHubFetchOrganizationsAPIRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 19.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@interface GitHubAPIFetchOrganizationsRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) NSString *username;
@property (nonatomic, readonly) NSArray *organizations;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials options:(NSDictionary *)options;
+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials username:(NSString *)username  options:(NSDictionary *)options;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials username:(NSString *)username options:(NSDictionary *)options;

@end
