//
//  GitHubFetchPublicKeysAPIRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 20.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@interface GitHubAPIFetchPublicKeysRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) NSArray *publicKeys;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials;

@end
