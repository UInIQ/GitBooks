//
//  GitHubUpdateUserAPIRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 19.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@class GitHubAPIAccount;
@interface GitHubAPIUpdateUserRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) GitHubAPIAccount *user;
@property (nonatomic, readonly) GitHubAPIAccount *updatedUser;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials user:(GitHubAPIAccount *)user;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials user:(GitHubAPIAccount *)user;

@end
