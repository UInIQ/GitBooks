//
//  GitHubAPIConstants.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 19.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const GitHubWebBaseURL;
extern NSString *const GitHubAPIBaseURL;
extern NSString *const GitHubAPIBasePath;

extern NSString *const GitHubAPIRequestOptionSearchString;

extern NSString *const GitHubAPIRequestOptionPage;
extern NSString *const GitHubAPIRequestOptionItemsPerPage;

extern NSString *const GitHubAPIRequestOptionAffiliation;
extern NSString *const GitHubAPIRequestOptionAffiliationOwner;
extern NSString *const GitHubAPIRequestOptionAffiliationCollaborator;
extern NSString *const GitHubAPIRequestOptionAffiliationOrganizationMember;

extern NSString *const GitHubAPIRequestOptionType;
extern NSString *const GitHubAPIRequestOptionTypeAll;
extern NSString *const GitHubAPIRequestOptionTypePrivate;
extern NSString *const GitHubAPIRequestOptionTypePublic;
extern NSString *const GitHubAPIRequestOptionTypeOwner;
extern NSString *const GitHubAPIRequestOptionTypeMember;
extern NSString *const GitHubAPIRequestOptionTypeForks;
extern NSString *const GitHubAPIRequestOptionTypeSources;

extern NSString *const GitHubAPIRequestOptionSort;
extern NSString *const GitHubAPIRequestOptionSortCreated;
extern NSString *const GitHubAPIRequestOptionSortUpdated;
extern NSString *const GitHubAPIRequestOptionSortPushed;
extern NSString *const GitHubAPIRequestOptionSortFullName;

extern NSString *const GitHubAPIRequestOptionDirection;
extern NSString *const GitHubAPIRequestOptionDirectionAscending;
extern NSString *const GitHubAPIRequestOptionDirectionDescending;

extern NSString *const GitHubAPIScopeUser;
extern NSString *const GitHubAPIScopeUserEmail;
extern NSString *const GitHubAPIScopeUserFollow;
extern NSString *const GitHubAPIScopePublicRepo;
extern NSString *const GitHubAPIScopeRepo;
extern NSString *const GitHubAPIScopeDeleteRepo;
extern NSString *const GitHubAPIScopeReadOrg;
extern NSString *const GitHubAPIScopeWriteOrg;
extern NSString *const GitHubAPIScopeAdminOrg;
extern NSString *const GitHubAPIScopeReadPublicKey;
extern NSString *const GitHubAPIScopeWritePublicKey;
extern NSString *const GitHubAPIScopeAdminPublicKey;
