//
//  GitHubAPIDeleteAuthorizationRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 16/06/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@interface GitHubAPIDeleteAuthorizationRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) NSUInteger authorizationID;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials authorizationID:(NSUInteger)authorizationID;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials authorizationID:(NSUInteger)authorizationID;

@end
