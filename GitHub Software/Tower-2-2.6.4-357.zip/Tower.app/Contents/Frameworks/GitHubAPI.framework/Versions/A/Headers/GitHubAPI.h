//
//  GitHubAPI.h
//  Tower
//
//  Created by Alexander Rinass on 12.04.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <FNFoundation/FNFoundation.h>

//! Project version number for GitHubAPI.
FOUNDATION_EXPORT double GitHubAPIVersionNumber;

//! Project version string for GitHubAPI.
FOUNDATION_EXPORT const unsigned char GitHubAPIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GitHubAPI/PublicHeader.h>

#import <GitHubAPI/GitHubAPIConstants.h>
#import <GitHubAPI/NSError+GitHubAPI.h>
#import <GitHubAPI/GitHubAPIHelpers.h>
#import <GitHubAPI/GitHubAPIModels.h>
#import <GitHubAPI/GitHubAPIClient.h>
#import <GitHubAPI/GitHubAPIRequest.h>
#import <GitHubAPI/GitHubAPIResponse.h>
