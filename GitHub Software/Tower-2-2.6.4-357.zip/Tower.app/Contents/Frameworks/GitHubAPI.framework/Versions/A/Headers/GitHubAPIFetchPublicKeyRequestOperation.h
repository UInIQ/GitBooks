//
//  GitHubFetchPublicKeyAPIRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 20.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@class GitHubAPIPublicKey;
@interface GitHubAPIFetchPublicKeyRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) NSInteger publicKeyID;
@property (nonatomic, readonly) GitHubAPIPublicKey *publicKey;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials publicKeyID:(NSInteger)publicKeyID;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials publicKeyID:(NSInteger)publicKeyID;

@end
