//
//  GitHubUpdateOrganizationAPIRequestOperation.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 19.06.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import "GitHubAPIRequestOperation.h"

@class GitHubAPIAccount;
@interface GitHubAPIUpdateOrganizationRequestOperation : GitHubAPIRequestOperation
@property (nonatomic, readonly) GitHubAPIAccount *organization;
@property (nonatomic, readonly) GitHubAPIAccount *updatedOrganization;

+ (instancetype)requestWithCredentials:(GitHubAPICredentials *)credentials organization:(GitHubAPIAccount *)organization;
- (instancetype)initWithCredentials:(GitHubAPICredentials *)credentials organization:(GitHubAPIAccount *)organization;

@end
