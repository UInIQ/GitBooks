//
//  GitHubAPIResponse.h
//  GitHubAPI
//
//  Created by Alexander Rinass on 22/04/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

#import <FNFoundation/FNFoundation.h>

@interface GitHubAPIResponse : FNRESTAPIResponse
@property (nonatomic, readonly) BOOL hasPrevPage;
@property (nonatomic, readonly) BOOL hasNextPage;
@property (nonatomic, readonly) NSUInteger nextPageNumber;
@property (nonatomic, readonly) NSUInteger prevPageNumber;
@property (nonatomic, readonly) NSUInteger numberOfTotalPages;
@property (nonatomic, readonly) NSUInteger numberOfItemsPerPage;
@property (nonatomic, readonly) NSUInteger rateLimit;
@property (nonatomic, readonly) NSUInteger rateLimitRemaining;
@property (nonatomic, readonly) NSDate *rateLimitResetDate;
@property (nonatomic, readonly) NSString *etag;
@end
