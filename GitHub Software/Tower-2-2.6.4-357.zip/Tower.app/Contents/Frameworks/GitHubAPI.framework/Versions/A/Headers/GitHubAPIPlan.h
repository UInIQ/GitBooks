//
//  GitHubPlan.h
//  Tower
//
//  Created by Alexander Rinass on 12.04.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <FNFoundation/FNFoundation.h>

@interface GitHubAPIPlan : FNRESTAPIModel
@property (nonatomic, readonly) NSString *name;
@property (nonatomic, readonly) NSInteger space;
@property (nonatomic, readonly) NSInteger collaborators;
@property (nonatomic, readonly) NSInteger privateRepositories;

+ (instancetype)planWithJSONObject:(NSDictionary *)JSONObject;

- (BOOL)isEqualToGitHubAPIPlan:(GitHubAPIPlan *)object;

@end
