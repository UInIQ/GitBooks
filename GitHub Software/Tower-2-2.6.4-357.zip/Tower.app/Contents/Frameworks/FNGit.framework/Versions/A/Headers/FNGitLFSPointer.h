//
//  FNGitLFSPointer.h
//  FNGit
//
//  Created by Heiko Witte on 30.08.16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNGitLFSPointer : NSObject
@property (nonatomic, readonly, nonnull) NSString *version;
@property (nonatomic, readonly, nonnull) NSString *objectID;
@property (nonatomic, readonly, nonnull) NSString *size;
@property (nonatomic, readonly, nonnull) NSDictionary<NSString *, NSString *> *allEntries;
@property (nonatomic, readonly, nonnull) NSString *stringRepresentation;

- (nullable instancetype)initWithDictionary:(nonnull NSDictionary<NSString *, NSString *> *)dictionary stringRepresentation:(nonnull NSString *)stringRepresentation;
@end
