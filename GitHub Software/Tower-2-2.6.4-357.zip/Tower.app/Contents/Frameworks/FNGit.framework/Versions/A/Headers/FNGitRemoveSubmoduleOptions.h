//
//  FNGitRemoveSubmoduleOptions.h
//  FNGit
//
//  Created by Alexander Rinass on 06/03/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

typedef NS_OPTIONS(NSUInteger, FNGitRemoveSubmoduleOptions) {
    FNGitRemoveSubmoduleOptionDefaults = 0,
    FNGitRemoveSubmoduleOptionForce = 1UL << 0,
    FNGitRemoveSubmoduleOptionKeepWorkingTree = 1UL << 1,
    FNGitRemoveSubmoduleOptionRemoveGitDirectory = 1UL << 2
};
