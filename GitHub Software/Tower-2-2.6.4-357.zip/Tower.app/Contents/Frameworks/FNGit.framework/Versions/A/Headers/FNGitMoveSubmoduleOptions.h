//
//  FNGitMoveSubmoduleOptions.h
//  FNGit
//
//  Created by Alexander Rinass on 09/04/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

typedef NS_OPTIONS(NSUInteger, FNGitMoveSubmoduleOptions) {
    FNGitMoveSubmoduleOptionNone = 0,
    FNGitMoveSubmoduleOptionForce = 1UL << 0
};
