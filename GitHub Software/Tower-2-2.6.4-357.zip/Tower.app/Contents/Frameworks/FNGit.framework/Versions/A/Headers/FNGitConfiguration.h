//
//  FNGitConfiguration.h
//  FNGit
//
//  Created by Alexander Rinass on 30/01/2017.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNGitConfiguration : NSObject
@property (nonatomic) NSUInteger maxConcurrentCommands;
@property (class, nullable, readonly) FNGitConfiguration *sharedConfiguration;
@end
