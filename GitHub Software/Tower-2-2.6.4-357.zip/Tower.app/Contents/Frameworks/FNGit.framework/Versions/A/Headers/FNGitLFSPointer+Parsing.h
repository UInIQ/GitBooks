//
//  FNGitLFSPointer+Parsing.h
//  FNGit
//
//  Created by Heiko Witte on 09.09.16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import "FNGitLFSPointer.h"
#import <FNFoundation/FNFoundation.h>

@interface FNGitLFSPointer (Parsing)

+ (nullable instancetype)pointerFromData:(nonnull NSData *)data;

@end
