//
//  FNGitSubmoduleIgnoreModes.h
//  FNGit
//
//  Created by Alexander Rinass on 06/03/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

typedef NS_ENUM(NSInteger, FNGitSubmoduleStatusIgnoreMode) {
    FNGitSubmoduleStatusIgnoreModeNoValue,
    FNGitSubmoduleStatusIgnoreModeNone,     // Show every modification to the submodule working tree or commit pointer
    FNGitSubmoduleStatusIgnoreModeAll,      // Completely ignore the submodule whatever comes
    FNGitSubmoduleStatusIgnoreModeDirty,    // Show as modified only if the commit pointer has changed
    FNGitSubmoduleStatusIgnoreModeUntracked // Show as modified only if modified files are in the working tree, ignoring untracked files
};
