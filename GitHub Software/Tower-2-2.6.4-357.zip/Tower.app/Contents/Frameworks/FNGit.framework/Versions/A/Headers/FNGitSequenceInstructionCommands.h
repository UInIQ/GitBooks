//
//  FNGitSequenceInstructionCommands.h
//  FNGit
//
//  Created by Alexander Rinass on 18/08/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const FNGitSequenceInstructionCommandPick;
extern NSString *const FNGitSequenceInstructionCommandReword;
extern NSString *const FNGitSequenceInstructionCommandDrop;
extern NSString *const FNGitSequenceInstructionCommandEdit;
extern NSString *const FNGitSequenceInstructionCommandSquash;
extern NSString *const FNGitSequenceInstructionCommandFixup;
