//
//  FNGitCherryPickOptions.h
//  FNGit
//
//  Created by Alexander Rinass on 03.09.13.
//  Copyright (c) 2013 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const FNGitCherryPickOptionMainlineParentNumber;
extern NSString *const FNGitCherryPickOptionCommitChanges;
extern NSString *const FNGitCherryPickOptionFastForward;
