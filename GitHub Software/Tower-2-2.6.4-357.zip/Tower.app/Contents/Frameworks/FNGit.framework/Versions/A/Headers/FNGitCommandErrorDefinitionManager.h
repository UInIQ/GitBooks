//
//  FNGitErrorMapper.h
//  FNGit
//
//  Created by Alexander Rinass on 25.07.12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FNFoundation/FNFoundation.h>
#import "FNGitCommandErrorDefinition.h"

@class FNGitCommand;
@interface FNGitCommandErrorDefinitionManager : NSObject

+ (id)defaultManager;

- (NSArray *)allGitCommandErrorDefinitions;
- (void)addGitCommandErrorDefinitions:(NSArray *)gitCommandErrorDefinitions;

- (FNGitCommandErrorDefinition *)gitCommandErrorDefinitionForCommand:(FNGitCommand *)command;

@end
