//
//  NSString+FNGit.h
//  FNGit
//
//  Created by Alexander Rinass on 19.07.11.
//  Copyright 2011 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (FNGit)
@property (nonatomic, readonly) NSString *unquotedCString;
@property (nonatomic, readonly) NSString *stringByEscapingReservedGitPatternCharacters;
@end
