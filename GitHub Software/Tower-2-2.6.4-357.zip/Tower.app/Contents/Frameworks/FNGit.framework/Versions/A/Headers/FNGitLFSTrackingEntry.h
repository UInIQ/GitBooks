//
//  FNGitLFSTrackingEntry.h
//  FNGit
//
//  Created by Heiko Witte on 30.08.16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNGitLFSTrackingEntry : NSObject
@property (nonatomic, readonly, nonnull) NSString *pattern;
@property (nonatomic, readonly, nonnull) NSString *fileName;

- (nullable instancetype)initWithPattern:(nonnull NSString *)pattern fileName:(nonnull NSString *)fileName;
@end
