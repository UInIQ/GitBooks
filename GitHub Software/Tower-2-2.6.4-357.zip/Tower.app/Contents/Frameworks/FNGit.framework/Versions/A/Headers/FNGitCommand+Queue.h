//
//  FNGitCommand+Queue.h
//  FNGit
//
//  Created by Alexander Rinass on 24/01/2017.
//  Copyright © 2017 Fournova GmbH. All rights reserved.
//

#import "FNGitCommand.h"

@interface FNGitCommand (Queue)

/** @name Running the Git Command Asynchronously */

- (void)enqueueCommand;

/** @name Running the Git Command Synchronously */

- (BOOL)run:(NSError * __autoreleasing *)error;

@end
