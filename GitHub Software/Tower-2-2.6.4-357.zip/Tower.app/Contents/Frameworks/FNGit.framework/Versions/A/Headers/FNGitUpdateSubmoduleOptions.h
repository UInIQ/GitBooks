//
//  FNGitUpdateSubmoduleOptions.h
//  FNGit
//
//  Created by Alexander Rinass on 06/03/15.
//  Copyright (c) 2015 Fournova GmbH. All rights reserved.
//

typedef NS_OPTIONS(NSUInteger, FNGitUpdateSubmoduleOptions) {
    FNGitUpdateSubmoduleOptionDefaults = 0,
    FNGitUpdateSubmoduleOptionInit = 1UL << 0,
    FNGitUpdateSubmoduleOptionRecursive = 1UL << 1,
    FNGitUpdateSubmoduleOptionForce = 1UL << 2
};
