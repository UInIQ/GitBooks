//
//  NSTableView+GTRegisterNibByName.h
//  Tower
//
//  Created by jens bissinger on 04/03/14.
//  Copyright (c) 2014 fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSTableView (FNRegisterNibByName)

- (void)registerNibByName:(NSString *)nibName;

@end
