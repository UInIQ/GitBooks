//
//  NSTableCellView+FNIsSelected.h
//  FNAppKit
//
//  Created by Alexander Rinass on 05/11/15.
//  Copyright © 2015 Fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSTableCellView (FNIsSelected)
@property (nonatomic, readonly, getter=isSelected) BOOL selected;
@end
