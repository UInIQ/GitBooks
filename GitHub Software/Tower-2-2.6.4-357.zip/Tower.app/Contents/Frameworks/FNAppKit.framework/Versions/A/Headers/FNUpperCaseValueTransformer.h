//
//  FNUpperCaseValueTransformer.h
//  FNAppKit
//
//  Created by Florian Bürger on 7/3/12.
//  Copyright (c) 2012 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNUpperCaseValueTransformer : NSValueTransformer

@end
