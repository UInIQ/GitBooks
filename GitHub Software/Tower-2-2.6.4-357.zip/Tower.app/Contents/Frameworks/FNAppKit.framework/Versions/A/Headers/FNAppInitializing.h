//
//  FNAppInitializing.h
//  FNAppKit
//
//  Created by Alexander Rinass on 20/01/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FNAppInitializing <NSObject>
@required

- (BOOL)initialize:(NSError * __autoreleasing *)error;

@optional

- (void)uninitialize;

@end
