//
//  NSPasteboard+FileURLs.h
//  FNAppKit
//
//  Created by Alexander Rinass on 18/01/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSPasteboard (FileURLs)

- (nonnull NSArray<NSURL *> *)fileURLsForType:(nonnull NSString *)type;

@end
