//
//  NSAlert+FNModal.h
//  FNAppKit
//
//  Created by Alexander Rinass on 15/08/14.
//  Copyright (c) 2014 Fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSAlert (FNModal)

- (void)_beginSheetModalForWindow:(NSWindow *)sheetWindow completionHandler:(void (^)(NSModalResponse returnCode))handler;

@end
