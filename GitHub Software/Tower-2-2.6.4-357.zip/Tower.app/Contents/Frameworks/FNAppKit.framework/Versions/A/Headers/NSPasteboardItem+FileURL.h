//
//  NSPasteboardItem+FileURL.h
//  FNAppKit
//
//  Created by Alexander Rinass on 18/01/16.
//  Copyright © 2016 Fournova GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSPasteboardItem (FileURL)

- (nullable NSURL *)fileURLforType:(nonnull NSString *)type;

@end
